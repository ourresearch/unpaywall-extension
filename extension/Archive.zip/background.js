if (typeof chrome !== "undefined" && chrome){
    browser = chrome
}

browser.runtime.onInstalled.addListener(function (object) {
    console.log("object reason", object)
    if(object.reason === 'install') {
        browser.tabs.create({url: "http://unpaywall.org/welcome"}, function (tab) {
        });
    }

});


//
// console.log("BACKGROUND.JS")
//if (require('sdk/self').loadReason ) {
//    // Do something on the very first install
//     console.log("INSTALLLLLL!!!!!")
//}